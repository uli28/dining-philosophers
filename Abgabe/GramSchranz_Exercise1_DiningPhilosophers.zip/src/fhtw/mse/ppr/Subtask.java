package fhtw.mse.ppr;

public enum Subtask {
    INITIAL_MODE,
    DEADLOCK_PREVENTION_MODE;
}
